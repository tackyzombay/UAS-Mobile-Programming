package com.test.uas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ConfirmBuy extends AppCompatActivity {

    Button yesbtn, nobtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_buy);
        yesbtn = findViewById(R.id.yesBtn);
        nobtn = findViewById(R.id.noBtn);

        yesbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ConfirmBuy.this, ThankYou.class);
                startActivity(i);
            }
        });

        nobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ConfirmBuy.this, Seat.class);
                startActivity(i);
            }
        });
    }
}