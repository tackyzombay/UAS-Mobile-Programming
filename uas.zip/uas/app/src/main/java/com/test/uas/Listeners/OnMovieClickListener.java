package com.test.uas.Listeners;

public interface OnMovieClickListener {
    void onMovieClicked(String id);
}
